<?php $__env->startSection('title', 'Daftar Pengguna'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Daftar Pengguna</h1>
        </div>

        <?php if($errors->any()): ?>
            
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: '<?= implode("\n", $errors->all()); ?>',
                    icon: 'error',
                    confirmButtonText: 'OK'
                })
            </script>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
            <script type="text/javascript">
                Swal.fire({
                    title: 'Berhasil!',
                    text: '<?= session()->get('success'); ?>',
                    icon: 'success',
                    confirmButtonText: 'OK'
                })
            </script>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Pengguna</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="tablePaging">
                                    <thead>
                                        <tr class="text-center">
                                            <th class="text-center">Nama</th>
                                            <th class="text-center">Nomor Telepon</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Alamat</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td><?php echo e($user->nama); ?></td>
                                                <td><?php echo e($user->no_hp); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td>
                                                    <?php if($user->check_admin == 'Terverifikasi'): ?>
                                                        <span class="badge badge-primary">Terverifikasi</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-warning">Belum Terverifikasi</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($user->alamat); ?></td>
                                                <td class="d-flex justify-content-center gap-1 align-items-center">
                                                    <?php if($user->check_admin == 'Belum Terverifikasi'): ?>
                                                        <form id="verifyForm_<?php echo e($user->id); ?>" action="<?php echo e(route('pengguna.update', $user->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <button type="submit" class="btn btn-success">
                                                                <i class="fas fa-check"></i> Verifikasi
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <form id="deleteForm_<?php echo e($user->id); ?>" action="<?php echo e(route('pengguna.destroy', $user->id)); ?>" method="post"
                                                        onsubmit="deleteData(event, 'deleteForm_<?php echo e($user->id); ?>')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="btn btn-danger">
                                                            <i class="fas fa-trash"></i> Hapus
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Function to confirm delete with Swal alert when submitting the form
        function deleteData(event, formId) {
            event.preventDefault();
            var form = document.getElementById(formId);

            Swal.fire({
                title: 'Apakah anda yakin?',
                text: "Anda tidak dapat mengembalikan data yang telah dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pengguna/index.blade.php ENDPATH**/ ?>