<?php $__env->startSection('title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Peminjaman</h1>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data Peminjaman</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-1">
                                    <label for="penulis" class="form-label"><b>Kode Peminjaman</b></label>
                                    <p><?php echo e($peminjaman->kode_peminjaman); ?></p>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <?php if($peminjaman->buku->gambar !== 'default.png'): ?>
                                        <img src="<?php echo e(asset('assets/buku/'.$peminjaman->buku->gambar)); ?>" alt="gambar buku" width="500" class="img-fluid">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/news/img01.jpg')); ?>" alt="gambar buku" width="500" class="img-fluid">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="kode_buku" class="form-label"><b>Kode Buku</b></label>
                                    <p><?php echo e($peminjaman->buku->kode_buku); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="judul_buku" class="form-label"><b>Judul Buku</b></label>
                                    <p><?php echo e($peminjaman->buku->judul_buku); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="deskripsi" class="form-label"><b>Nama Pengunjung</b></label>
                                    <p><?php echo e($peminjaman->user->nama); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="tgl_kunjungan" class="form-label"><b>Tanggal Kunjungan</b></label>
                                    <p><?php echo e($peminjaman->tgl_kunjungan); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="tujuan" class="form-label"><b>Tujuan Kunjungan</b></label>
                                    <p><?php echo e($peminjaman->tujuan); ?></p>
                                </div>
                                <div class="col-md-12 mb-1">
                                    <label for="tujuan" class="form-label"><b>Status</b></label>
                                    <p><?php echo e($peminjaman->status); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-warning">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/peminjaman/show.blade.php ENDPATH**/ ?>