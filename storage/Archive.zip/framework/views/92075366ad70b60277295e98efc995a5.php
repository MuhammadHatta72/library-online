<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Profile</h1>
        </div>

        <?php if(session()->has('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            </script>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: '<?php echo e(session('error')); ?>',
                });
            </script>
        <?php endif; ?>

        <div class="section-body">
            <div class="container-xl px-4 mt-4">
                <hr class="mt-0 mb-4" />
                <div class="row">
                    <div class="col-xl-12">
                        <!-- Edit profile card-->
                        <div class="card mb-4">
                            <div class="card-header bg-whitesmoke">
                                <h4>Profile</h4>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin-profile.update', auth()->user()->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="row">
                                        <div class="mb-3 col-md-6">
                                            <label class="small mb-1" for="inputName">Nama</label>
                                            <input class="form-control" id="inputName" type="text" name="nama"
                                                value="<?php echo e(auth()->user()->nama); ?>"/>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label class="small mb-1" for="inputEmailAddress">Email</label>
                                            <input class="form-control" id="inputEmailAddress" type="email" name="email"
                                                value="<?php echo e(auth()->user()->email); ?>"/>
                                        </div>
                                    </div>
                                    <div class="row">
                                        
                                    </div>
                                    <div class="card-header bg-whitesmoke">
                                        <h4>Ubah Password</h4>
                                    </div>
                                    <div class="mb-4 col-md-6">
                                        <label class="small mb-1" for="password">Password</label>
                                        <div class="d-flex align-items-center justify-content-end">
                                            <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="password" type="password" name="password" />
                                            <span class="position-absolute px-1">
                                                <button class="eye btn border-0" type="button" onclick="showPW()">
                                                    <i class="fas fa-eye fs-6"></i>
                                                </button>
                                                <button class="eye-slash btn border-0 d-none" type="button"
                                                    onclick="hidePW()">
                                                    <i class="fas fa-eye-slash fs-6"></i>
                                                </button>
                                            </span>
                                        </div>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-inline-flex">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <button class="btn btn-primary">Simpan</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/profile_user/index.blade.php ENDPATH**/ ?>