<div class="footer-left">
    Copyright &copy; 2023
    <div class="bullet"></div>
    Developed By Desy Shofiatul hidayah 2023.
</div>
<div class="footer-right">0.1</div>
<?php /**PATH /var/www/html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>