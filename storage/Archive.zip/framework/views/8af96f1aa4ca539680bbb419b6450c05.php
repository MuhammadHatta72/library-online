<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/pppbulutuban.png')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - UPT PPP Bulu Tuban</title>

    <!-- General CSS Files -->
    
    

    <link href="<?php echo e(asset('assets/css/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    
    

    <link href="<?php echo e(asset('assets/css/vendor/fontawesome-free-5.15.4-web/css/all.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/DataTables-1.13.6/css/dataTables.bootstrap5.min.css')); ?>">


    

    <script src="<?php echo e(asset('assets/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/Jquery/jquery-3.6.0.min.js')); ?>"></script>


    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor/select2/select2.min.css')); ?>">
    <script src="<?php echo e(asset('assets/css/vendor/select2/select2.min.js')); ?>"></script>

    <!-- CSS Libraries -->
    <?php echo $__env->yieldPushContent('customCSS'); ?>
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>" />
</head>

<body>
    <div id="app">
        <div class="main-wrapper">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </nav>
            <div class="main-sidebar sidebar-style-2">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <footer class="main-footer">
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </footer>
        </div>
    </div>

    <!-- General JS Scripts -->
    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    
    
    
    <script src="<?php echo e(asset('assets/css/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    
    <script src="<?php echo e(asset('assets/vendor/DataTables-1.13.6/js/jquery.dataTables.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/vendor/DataTables-1.13.6/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>


    <!-- JS Libraies -->
    <?php echo $__env->yieldPushContent('customJS'); ?>


    <!-- Template JS File -->
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert.js')); ?>"></script>

</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>